package com.classselector;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class QuestKeys {
    public static final KeyMapping OPEN = new KeyMapping("key.classselector.quests",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.classselector");

    public static final KeyMapping SKILLS = new KeyMapping("key.classselector.skills",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.classselector");

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(OPEN);
        e.register(SKILLS);
    }
}
