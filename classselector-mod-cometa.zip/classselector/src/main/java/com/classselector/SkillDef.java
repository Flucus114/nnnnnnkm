package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Um nó da árvore de habilidades. */
public class SkillDef {
    public String id = "", tree = "", parent = "", name = "", description = "";
    public String icon = "minecraft:nether_star";
    /** Classe que pode ver e desbloquear esta habilidade ("" = todas). */
    public String classId = "";
    /** Níveis de XP gastos para desbloquear (0 = grátis). */
    public int xpCost = 0;
    /** Níveis de XP recebidos ao desbloquear. */
    public int xpReward = 0;
    /** Itens recebidos ao desbloquear. */
    public List<ItemStack> rewards = new ArrayList<>();

    public ItemStack iconStack() {
        ResourceLocation rl = ResourceLocation.tryParse(icon);
        Item it = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(it == null || it == Items.AIR ? Items.BARRIER : it);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("id", id);
        t.putString("tree", tree);
        t.putString("parent", parent);
        t.putString("name", name);
        t.putString("description", description);
        t.putString("icon", icon);
        t.putString("classId", classId);
        t.putInt("xpCost", xpCost);
        t.putInt("xpReward", xpReward);
        ListTag l = new ListTag();
        for (ItemStack s : rewards) l.add(s.save(new CompoundTag()));
        t.put("rewards", l);
        return t;
    }

    public static SkillDef load(CompoundTag t) {
        SkillDef d = new SkillDef();
        d.id = t.getString("id");
        d.tree = t.getString("tree");
        d.parent = t.getString("parent");
        d.name = t.getString("name");
        d.description = t.getString("description");
        d.icon = t.getString("icon");
        d.classId = t.getString("classId");
        d.xpCost = Math.max(0, t.getInt("xpCost"));
        d.xpReward = Math.max(0, t.getInt("xpReward"));
        for (Tag x : t.getList("rewards", Tag.TAG_COMPOUND)) {
            ItemStack s = ItemStack.of((CompoundTag) x);
            if (!s.isEmpty()) d.rewards.add(s);
        }
        return d;
    }
}
